#nestedForLoop.py
print("i","j", "i+j")
for i in range(5):
    for j in range(5):
        val = i + j
        print(i,j, val)