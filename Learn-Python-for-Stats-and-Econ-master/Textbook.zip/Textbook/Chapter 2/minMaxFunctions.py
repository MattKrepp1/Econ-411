#minMaxFunctions.py

list1 = [20,30, 40, 50]
max_list_value = max(list1)
min_list_value = min(list1)
print("maximum:", max_list_value, "min:", min_list_value)