#fullSlice.py
some_list = [3, 1, 5, 6, 1]
print(some_list[:])