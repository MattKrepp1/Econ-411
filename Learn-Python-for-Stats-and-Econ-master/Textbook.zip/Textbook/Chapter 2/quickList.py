#quickList.py

list1 = list(range(0,1001,2))
print(list1)