#concatenateLists

list1 = [5, 4, 9, 10, 3, 5]
list2 = [6, 3, 2, 1, 5, 3]
join_lists = list1 + list2

print("list1:", list1)
print("list2:", list2)
print(join_lists)