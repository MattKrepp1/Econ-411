#partialSlice.py
some_list = [3, 1, 5, 6, 1]
minimum = 0
maximum = len(some_list)
print("minimum:", minimum)
print("maximum:", maximum)
print("Full list using slice", some_list[minimum:maximum])
print("Full list without slice", some_list)