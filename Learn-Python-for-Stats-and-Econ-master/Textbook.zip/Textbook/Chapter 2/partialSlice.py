#partialSlice.py  
min_index = 3  
max_index = 7  
full_list = [1,2,3,4,5,6,7,8,9]  
partial_list = full_list[min_index:max_index]  
print(full_list)  
print(partial_list)  
  
print("full_list[7]:", full_list[7])