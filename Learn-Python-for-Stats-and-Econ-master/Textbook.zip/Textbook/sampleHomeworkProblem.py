#sampleHomeworkProblem.py
print("""
James Caton
ECON 411 (611 for Grad Students)
Homework 1 (Practice)
""")
print("""
1. Save your name as 3 or more separate objects (3 separate variables) and 
concatenate those objects and save the result in a new variable. 
Print the result:""")

# create objects with variable names identifying their meaning
first_name = "James"
middle_name = "Lee"
last_name = "Caton"

# concatenate the tree variables
full_name = first_name + " "  + middle_name + " " + last_name

print("""
SCRIPT:
# create objects with variable names identifying their meaning
first_name = "James"
middle_name = "Lee"
last_name = "Caton"

# concatenate the tree variables
full_name = first_name + " "  + middle_name + " " + last_name

RESULT:""")

print("Full Name:", full_name)


print("""
EXPLANATION:
In lines 21-23, I create string objects for my first, middle,
and last names. In line 26, I concatenate them using the "+" sign and include a
space between each variable in the same manner.
""" )