#specialValuesInNumpy.py
import numpy as np

pi = np.pi
e = np.e
lne = np.log(e)
infinity = np.inf
nullVal = np.nan
print("pi =", pi)
print("e =", e)
print("ln(e)=", lne)
print("infintity:", infinity)
print("nullVal:",nullVal)