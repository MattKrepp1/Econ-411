#numpyInstantArrays.py
import numpy as np

rangeArray = np.arange(0,101)
rangeArray2 = np.arange(0,101, 2)

print(rangeArray)
print(rangeArray2)