#numpyLogs.py

vals = np.arange(0, 10001, 100)
lnVals = np.log(vals)
log10Vals = np.log10(vals)
print(vals)
print(lnVals)
print(log10Vals)