#numpyZeroArrays.py
import numpy as np

zeroArray = np.zeros(25)
zeroArray2 = np.zeros((5,5))

print(zeroArray)
print(zeroArray2)