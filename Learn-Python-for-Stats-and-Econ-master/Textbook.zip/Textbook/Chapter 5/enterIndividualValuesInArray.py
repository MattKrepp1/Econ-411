import numpy as np

array = np.zeros((3,3))
print(array)

array[0][2] = 9
array[1][0] = 7
array[2][2] = 3
print(array)