#playRPG.py
import RPG

rpg = RPG.RPG(num_humans = 1, num_computers = 3, difficulty = "easy")
rpg.play_tournament()
