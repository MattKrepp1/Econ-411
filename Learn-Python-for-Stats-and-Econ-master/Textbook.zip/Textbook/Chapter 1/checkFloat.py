#checkFloat.py
import sys
print(sys.float_info)