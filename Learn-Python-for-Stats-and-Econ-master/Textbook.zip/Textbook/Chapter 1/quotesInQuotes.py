#quotesInQuotes.py
single_in_double = "We may use 'single quotes' within double quotes"
double_in_single = 'We may use "double quotes" within single quotes'
print(single_in_double)
print(double_in_single)