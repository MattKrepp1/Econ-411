#helloWorld.py
print("Hello world!")
