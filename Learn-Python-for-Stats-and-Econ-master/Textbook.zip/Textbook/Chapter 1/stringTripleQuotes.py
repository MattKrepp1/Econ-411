#stringTripleQuotes.py
x = """\
Everything in this object will be recorded exactly as entered,
if we enter a new line or 
    a new line with a tab."""
    
print(x)