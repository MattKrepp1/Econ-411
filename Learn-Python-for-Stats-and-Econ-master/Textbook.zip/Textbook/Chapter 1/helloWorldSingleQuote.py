#helloWorldSingleQuote.py
print('Hello world!')