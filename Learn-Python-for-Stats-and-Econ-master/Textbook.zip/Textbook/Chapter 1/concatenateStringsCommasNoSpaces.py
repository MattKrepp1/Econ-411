#concatenateStringsCommasNoSpaces.py
line1 = "You thought it would be easy"
line2 = "You thought it wouldn't be strange"
line3 = "But then you started coding"
line4 = "Things never were the same"
# Now the comma inserts and empty string instead of a space
print(line1, line2, line3, line4, sep = "")