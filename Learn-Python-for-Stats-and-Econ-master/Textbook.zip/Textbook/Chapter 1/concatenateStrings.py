#concatenateStrings.py
# join 3 different strings and save the result as msg
msg = "john" + " " + "nash"
print(msg)