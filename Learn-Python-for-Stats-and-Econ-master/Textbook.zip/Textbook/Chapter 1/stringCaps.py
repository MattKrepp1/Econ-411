#stringCaps.py
msg = "john nash"
print(msg)

# ALL CAPS
msg_upper = msg.upper()
print(msg_upper)

# First Letter Of Each Word Capitalized
msg_title = msg.title()
print(msg_title)