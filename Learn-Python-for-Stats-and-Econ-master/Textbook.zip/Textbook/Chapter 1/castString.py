#castString.py
num1 = 5 / 3
num2 = 5 / 4
num3 = 4 / 3
sum_nums = num1 + num2 + num3

print("num1 + num2 + num3: " + str(sum_nums))
