#escapeSequences.py
single_quotes = 'We may use \'single quotes\' in single quotes.'
double_quotes = "Or we may use \"double quotes\" in double quotes."
read_backslash = "We may use two backslashes to print a single backslash: \\"
lines = "Every\nword\nis\na\nnew\nline"
new_line_and_tab = "We may start a new line \n\tand use tab for a hanging indent"

print(single_quotes)
print(double_quotes)
print(read_backslash)
print(lines)
print(new_line_and_tab)