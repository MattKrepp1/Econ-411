#concatenateStringsNewLines.py
line1 = "You thought it would be easy"
line2 = "You thought it wouldn't be strange"
line3 = "But then you started coding"
line4 = "Things never were the same"
# Concatenate each string with the escape seequence that creates a new line
print(line1 + "\n" + line2 + "\n" + line3 + "\n" + line4)