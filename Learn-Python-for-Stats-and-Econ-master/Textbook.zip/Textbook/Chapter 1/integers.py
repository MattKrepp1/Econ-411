#integers.py

num1 = 5 + 3
num2 = 5 - 4
num3 = 4 - 3

print("num1:", num1,"\nnum2:", num2, "\nnum3:", num3)
