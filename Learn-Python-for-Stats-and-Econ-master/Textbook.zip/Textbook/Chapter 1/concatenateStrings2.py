#concatenateStrings2.py
line1 = "You thought it would be easy"
line2 = "You thought it wouldn't be strange"
line3 = "But then you started coding"
line4 = "Things never were the same"
# concatenate the above strings while passing to print()
print(line1 + line2 + line3 + line4)