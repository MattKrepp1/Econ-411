#integersVsStrings.py

num1 = 5 + 3
num1s = "5" + "3"

print("num1:", num1,"\nnum1s:", num1s)