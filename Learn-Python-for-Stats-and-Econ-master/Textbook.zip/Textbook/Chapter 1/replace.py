#replace.py
spaces = "    Look at all the spaces in the text!    "
print("no spaces removed:\n", spaces)

remove_all_spaces = spaces.replace(" ", "")
print("Remove all spaces:\n" + remove_all_spaces)