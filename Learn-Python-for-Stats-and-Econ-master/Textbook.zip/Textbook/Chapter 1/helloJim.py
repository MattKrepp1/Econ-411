#helloJim.py
msg = "Hello Jim!"
print(msg)