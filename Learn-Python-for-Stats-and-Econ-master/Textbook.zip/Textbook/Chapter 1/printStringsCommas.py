#printStringsSpaces.py
line1 = "You thought it would be easy"
line2 = "You thought it wouldn't be strange"
line3 = "But then you started coding"
line4 = "Things never were the same"
# using a comma between each object includes a space to separate them
print(line1, line2, line3, line4)