#homeworkLayout.py
print("""
James Caton
ECON 411 / 611
Homework
""")

print("""
1. Record your name in an object (x = ...) and a description of yourself in 
another object. 
""")



print("""
SCRIPT:

RESULT:
""")

    
print("""
EXPLANATION:

""")    


    
    

print("""
2. Raise 2 to the 4th power. Save the value as an object named 
two_to_the_fourth. Then create a new value that sums the value twice. 
Create another variable that saves the value of twoToTheFourth as a string. 
Just as with the numeric value, sum the string object twice.
""")

print("""
SCRIPT:

    
    
RESULT:
""")

print("""
EXPLANATION:

""")    
    
    
    
    
print("""
3. Find the list of escape sequences in section 2.4: 
https://docs.python.org/3/reference/lexical_analysis.html#literals 
create a string that uses at least 4 different escape sequences.
""")

tab_word = "I use the \t tab escape sequence"
new_line = "It was boring,\nso I made a new line"
escape_quote = "How \"convenient\" it is to include scare quote"
backslash = "And who knew that \"\\\" did so much work!"

    
print("""
SCRIPT:
tab_word = "I use the \\t tab escape sequence"
new_line = "It was boring,\\nso I made a new line"
escape_quote = "How \\"convenient\\" it is to include scare quote"
backslash = "And who knew that \\"\\\\\\" did so much work!"

    
RESULT:
""")  
print(tab_word, new_line, escape_quote, backslash, sep="\n")
    
    
print("""
EXPLANATION:
I created four different objects using different escape sequences. Getting the
result to print correctly under SCRIPT was something of a challenge as I had to 
backslashes in front of every backslash. This might have been easier if I had
used ctrl-r and replaced each (single) \ with (double) \\
""")    






print("""    
4. Add an integer and a float together. Is the final number an integer or a 
float?
""")


print("""
SCRIPT:

    
    
RESULT:
""")


    
print("""
EXPLANATION:

""")    
    
    
    
    
    
    
print("""
5. Add 2 ** 1024 + 1.5. What is the outcome? Why? hint: Try adding .5, 1, and  
1.1 instead of 1.5.
""")

print("""
SCRIPT:

    
    
RESULT:
""")

    
print("""
EXPLANATION:
    
""")
    
    
