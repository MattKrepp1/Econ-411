#regression.py
import pandas as pd
import numpy as np
import copy
from stats import *
from scipy.stats import t, f
import sys

class Regression:
    def __init__(self):
        self.stats = stats()
        self.reg_history = {}
        
    def OLS(self, reg_name, data, y_name, beta_names, min_val = 0,
            max_val = None, constant = True):
        # min_val and max_val set index range by index number
        self.min_val = min_val
        if max_val != None:
            self.max_val = max_val
        else:
            self.max_val = len(data)
        self.reg_name = reg_name
        # enodogenous variable name
        self.y_name = y_name
        # names of X variables
        self.beta_names = copy.copy(beta_names)
        #make a copy of the data that is passed to OLS
        self.data = data.copy()
        # if the OLS regression has a constant, add column of 1s to data
        if constant:
            self.add_constant()
        self.build_matrices() 
        self.estimate_betas_and_yhat()
        self.calculate_regression_stats()
        self.save_output()
    
    def panel_regression(self, reg_name, data, y_name, X_names, min_val = 0,
                         max_val = None, entity = False, time = False, 
                         constant = True):
        if (entity and time) or (not entity and not time):
            print("Choose time OR entity")
            sys.exit()
        #identify which index column holds dates, which holds entities
        for i in range(len(data.index.levels)):
            if isinstance(data.index.levels[i], pd.DatetimeIndex):
                date_level = i
                date_index_name = data.index.names[date_level]
            else:
                entity_level = i
                entity_index_name = data.index.names[entity_level]
        #save name of selected index
        index_name = entity_index_name if entity else date_index_name
        # reduce list to unique elements and sort
        self.indicator_names = list(data.groupby(index_name).mean().index)
        self.indicator_names.pop()
        
        for indicator in self.indicator_names:
            self.create_indicator_variable(data, indicator, index_name, 
                                           [indicator])
        X_and_indicator_names = X_names + self.indicator_names
        self.OLS(reg_name, data = data, y_name = y_name, 
                 beta_names = X_and_indicator_names, min_val = min_val,
                 max_val = max_val, constant = constant)
        self.X_names = X_names + ["Constant"]
        self.data = self.data[self.X_names]
        self.estimates = self.estimates.loc[self.X_names]
        
    def create_indicator_variable(self,data, indicator_name, index_name, 
                                  target_index_list):
        # Prepare column with name of indicator variable
        data[indicator_name] = 0
        # for each index whose name matches an entry in target_index_list
        # a value of 1 will be recorded
        for index in target_index_list:
            data.loc[data.index.get_level_values(\
                index_name) == index, indicator_name] = 1
     
    def add_constant(self):
        self.data["Constant"] = 1
        self.beta_names.append("Constant")
    
    def build_matrices(self):
        # Transform dataframews to matrices
        self.y = np.matrix(self.data[self.y_name][self.min_val:self.max_val])
        # create a k X n nested list containing vectors for each exogenous var
        self.X = np.matrix(self.data[self.beta_names])
        self.X_transpose = np.matrix(self.X).getT()
        # (X'X)**-1
        X_transp_X = np.matmul(self.X_transpose, self.X)
        self.X_transp_X_inv = X_transp_X.getI()
        # X'y
        self.X_transp_y = np.matmul(self.X_transpose, self.y)
        
    def estimate_betas_and_yhat(self):
        # betas = (X'X)**-1 * X'y
        self.betas = np.matmul(self.X_transp_X_inv, self.X_transp_y)
        # y_hat = X * betas
        self.y_hat = np.matmul(self.X, self.betas)
        # Create a column that hold y-hat values
        #.item(n) pulls nth value from matrix
        self.data[self.y_name[0] + " estimator"] = \
            [i.item(0) for i in self.y_hat]
        # create a table that holds the estimated coefficient
        # this will also be used to store SEs, t-stats, and p-values
        self.estimates = pd.DataFrame(self.betas, index = self.beta_names,
                                      columns = ["Coefficient"])
        # identify y variable in index
        self.estimates.index.name = "y = " + self.y_name[0]        
        
    def calculate_regression_stats(self):
        self.sum_square_stats()
        self.calculate_degrees_of_freedom()
        self.calculate_estimator_variance()
        self.calculate_covariance_matrix()
        self.calculate_t_p_error_stats()
        self.calculate_MSE()
        self.calculate_rsquared()
        self.calculate_fstat()
        self.build_stats_DF()
        
    def sum_square_stats(self):
        ssr_list = []
        sse_list = []
        sst_list = []
        mean_y = self.stats.mean(self.y).item(0)
        for i in range(len(self.y)):
            # ssr is sum of squared distances between the estimated y values
            # (y-hat) and the average of y values (y-bar)
            yhat_i = self.y_hat[i]
            y_i = self.y[i]
            r = yhat_i - mean_y
            e = y_i - yhat_i
            t = y_i - mean_y
            ssr_list.append((r) ** 2)
            sse_list.append((e) ** 2)
            sst_list.append((t) ** 2)
            
        # call item - call value instead of matrix
        self.ssr = self.stats.total(ssr_list).item(0)
        self.sse = self.stats.total(sse_list).item(0)
        self.sst = self.stats.total(sst_list).item(0)
        
    def calculate_degrees_of_freedom(self):
        # Degrees of freedom compares the number of observations to the number
        # of exogenous variables used to form the prediction
        self.lost_degrees_of_freedom = len(self.estimates)
        self.num_obs = self.max_val + 1 - self.min_val
        self.degrees_of_freedom = self.num_obs - self.lost_degrees_of_freedom
        
    def calculate_estimator_variance(self):
#        estimator variance is the sse normalized by the degrees of freedom
        # thus, estimator variance increases as the number of exogenous
        # variables used in estimation increases(i.e., as degrees of freedom 
        # fall)
        self.estimator_variance = self.sse / self.degrees_of_freedom
        
    def calculate_covariance_matrix(self):
        # Covariance matrix will be used to estimate standard errors for
        # each coefficient.
        # estimator variance * (X'X)**-1
        self.cov_matrix = float(self.estimator_variance) * self.X_transp_X_inv
        self.cov_matrix = pd.DataFrame(self.cov_matrix,
                                       columns = self.beta_names,
                                       index = self.beta_names)

    def calculate_t_p_error_stats(self):
        ratings = [.05, .01, .001]
        results = self.estimates
        stat_sig_names = ["SE", "t-stat", "p-value"]
        # create space in data frame for SE, t, and p
        for stat_name in stat_sig_names:
            results[stat_name] = np.nan
        # generate statistic for each variable
        for var in self.beta_names:
            # SE ** 2 of coefficient is found in the diagonal of cov_matrix
            results.loc[var]["SE"] = self.cov_matrix[var][var] ** (1/2)
            
            # t-stat = Coef / SE
            results.loc[var]["t-stat"] = \
                results["Coefficient"][var] / results["SE"][var]
            # p-values is estimated using a table that transforms t-value in 
            # light of degrees of freedom
            results.loc[var]["p-value"] = np.round(t.sf(np.abs(results.\
                       loc[var]["t-stat"]), self.degrees_of_freedom + 1) * 2, 5)
        # values for significances will be blank unless p-values < .05
        # pandas does not allow np.nan values or default blank strings to 
        # be replaced x-post
        significance = ["" for i in range(len(self.beta_names))]
        for i in range(len(self.beta_names)):
            var = self.beta_names[i]
            for val in ratings:
                if results.loc[var]["p-value"] < val:
                    significance[i] = significance[i]  + "*"
        results["signficance"] = significance
        
    def calculate_MSE(self):
        self.mse = self.estimator_variance ** (1/2)
    
    def calculate_rsquared(self):
        self.r_sq = self.ssr / self.sst
        self.adj_r_sq = 1 - self.sse / self.degrees_of_freedom / (self.sst \
                            / (self.num_obs - 1))
        
    def calculate_fstat(self):
        self.f_stat = (self.sst - self.sse) / (self.lost_degrees_of_freedom\
                      - 1) / self.estimator_variance
        
    def build_stats_DF(self):
        stats_dict = {"r**2": [self.r_sq],
                      "Adj. r**2": [self.adj_r_sq],
                      "f-stat":[self.f_stat],
                      "Est Var":[self.estimator_variance],
                      "MSE":[self.mse],
                      "SSE":[self.sse],
                      "SSR":[self.ssr],
                      "SST":[self.sst],
                      "Obs.":[int(self.num_obs)],
                      "DOF":[int(self.degrees_of_freedom)]}
        self.stats_DF = pd.DataFrame(stats_dict)
        self.stats_DF = self.stats_DF.rename(index={0:"Estimation Statistics"})
        self.stats_DF = self.stats_DF.T
        
    def save_output(self):
        self.reg_history[self.reg_name] = {"Reg Stats": self.stats_DF.copy(),
                        "Estimates": self.estimates.copy(),
                        "Cov Matrix":self.cov_matrix.copy()}
    

    
    def joint_f_test(self, reg1_name, reg2_name):  
        # identify data for each regression  
        reg1 = self.reg_history[reg1_name]         
        reg2 = self.reg_history[reg2_name]  
        # identify beta estimates for each regression to draw variables  
        reg1_estimates = reg1["Estimates"]          
        reg2_estimates = reg2["Estimates"]  
        # name of y_var is saved as estimates index name  
        reg1_y_name = reg1_estimates.index.name  
        reg2_y_name = reg2_estimates.index.name  
        num_obs1 = reg1["Reg Stats"].loc["Obs."][0]  
        num_obs2 = reg2["Reg Stats"].loc["Obs."][0]  
        # check that the f-stat is measuring restriction, not for diff data sets
        if num_obs1 != num_obs2:   
            self.joint_f_error()  
        if reg1_y_name == reg2_y_name:          
            restr_reg = reg1 if \
            len(reg1_estimates.index) < len(reg2_estimates.index) else reg2 
            unrestr_reg = reg2 if restr_reg is reg1 else reg1  
            restr_var_names = restr_reg["Estimates"].index  
            unrestr_var_names = unrestr_reg["Estimates"].index  
            # identify statistics for each regression  
            restr_reg = restr_reg if False not in \
            [key in unrestr_var_names for key in restr_var_names] else None
            if restr_reg == None:  
                self.joint_f_error()  
            else:  
                sser = restr_reg["Reg Stats"].loc["SSE"][0]  
                sseu = unrestr_reg["Reg Stats"].loc["SSE"][0]  
                dofr = restr_reg["Reg Stats"].loc["DOF"][0]       
                dofu = unrestr_reg["Reg Stats"].loc["DOF"][0]  
                dfn = dofr - dofu  
                dfd = dofu - 1  
                f_stat = ((sser - sseu) / (dfn)) / (sseu / (dfd))  
                f_crit_val = 1 - f.cdf(f_stat,dfn = dfn, dfd = dfd)  
                #make dictionary?  
                f_test_label = "h_0"  
                for key in unrestr_var_names:  
                    if key not in restr_var_names:  
                        f_test_label = f_test_label + str(key) + " == "  
                f_test_label = f_test_label + "0"  
                res_dict = {"f-stat":[f_stat],  
                            "p-value":[f_crit_val],  
                            "dfn":[dfn],  
                            "dfd":[dfd]}  
                res_DF = pd.DataFrame(res_dict)  
                res_DF = res_DF.rename(index={0:""})  
                res_DF = res_DF.T  
                res_DF.index.name = f_test_label  
                
                return res_DF  
          
    def joint_f_error(self):  
        print("Regressions not comparable for joint F-test")  
        return None  

        
        
        
        
        
        
        
        
    
    